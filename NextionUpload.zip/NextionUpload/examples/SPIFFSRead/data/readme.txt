Place your .tft files in this data directory and upload it with the "ESP Sketch Data Upload" tool in Arduino IDE under tools.
